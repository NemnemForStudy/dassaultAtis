import java.util.*;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;

import matrix.db.Context;
import matrix.util.StringList;

public class PromoteChangeAction_mxJPO {

	public void promoteAutoChange(Context context, String[] args) throws Exception {
		try {
			String objectId = args[0];
			DomainObject testId = new DomainObject(objectId);
			
			StringList valueList = new StringList();
			valueList.add("id");
			valueList.add("type");
			valueList.add("current");

	        MapList mapList = testId.getRelatedObjects(context,
	                "Subtask",
	                "*",
	                valueList,
	                null,
	                false,
	                true,
	                (short) 0,
	                null,
	                null,
	                0);
	        
	        for (int i = 0; i < mapList.size(); i++) {
	            Map map = (Map) mapList.get(i);
	            String current = (String)map.get("current");
	            DomainObject object = new DomainObject((String) map.get("id"));
	            
	            if(current.equalsIgnoreCase("Create")) {
					object.setState(context, "Assign");
				}
	        }
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}