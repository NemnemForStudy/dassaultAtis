import java.io.PrintWriter;
import java.util.*;

import com.aspose.pdf.Id;
import com.dassault_systemes.plm.config.exposed.constants.Domain;
import com.matrixone.apps.domain.DomainAccess;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

public class LivartProject_mxJPO {
	public MapList findPerson(Context context, String[] args) throws Exception {
		StringList selects = new StringList("id");
		return DomainObject.findObjects(context, "Person", "*", "", selects);
	}

	public void connectPerson(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");

		String objectId = (String) paramMap.get("objectId");
		String newValue = (String) paramMap.get("New Value");
		try {
			DomainObject getId = new DomainObject(objectId);

			StringList map = getId.getInfoList(context, "relationship[livProjectDesigner].id");
			String[] values = newValue.split(",");
			String noVal = "";
			if (newValue == noVal) return;
			if (map != null) {
				for (String str : map) {
					DomainRelationship.disconnect(context, str);
				}
				for (String selectedValue : values) {
					DomainRelationship.connect(context, objectId, "livProjectDesigner", selectedValue, true);
					DomainRelationship.connect(context, objectId, "Member", selectedValue, true);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	public void connectSecondPerson(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");

		String objectId = (String) paramMap.get("objectId");
		String newValue = (String) paramMap.get("New Value");
		try {
			DomainObject getId = new DomainObject(objectId);

			StringList map = getId.getInfoList(context, "relationship[livProjectEngineer].id");

			String[] values = newValue.split(",");
			String noVal = "";
			if (newValue == noVal) return;
			if (map != null) {
				for (String str : map)
					DomainRelationship.disconnect(context, str);
			}
			for (String selectedValue : values) {
				DomainRelationship.connect(context, objectId, "livProjectEngineer", selectedValue, true);
				DomainRelationship.connect(context, objectId, "Member", selectedValue, true);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
